import copy
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import random
import os
import seaborn as sns
import time
import skimage
import pprint
from skimage import io, transform
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
import torchvision
from torchvision import datasets, models, transforms
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix, ConfusionMatrixDisplay
from torch.utils.data import WeightedRandomSampler

EPOCHS = 20
data_dir = "./data/chest_xray"
TEST = 'test'
TRAIN = 'train'
VAL = 'val'
balance = True


def extract_patient_ids(filename):
    patient_id = filename.split('_')[0].replace("person", "")
    return patient_id

def split_file_names(input_folder, val_split_perc):
    # Pneumonia files contain patient id, so we group split them by patient to avoid data leakage
    pneumonia_patient_ids = set([extract_patient_ids(fn) for fn in os.listdir(os.path.join(input_folder, 'PNEUMONIA'))])
    pneumonia_val_patient_ids = random.sample(list(pneumonia_patient_ids), int(val_split_perc * len(pneumonia_patient_ids)))

    pneumonia_val_filenames = []
    pneumonia_train_filenames = []

    for filename in os.listdir(os.path.join(input_folder, 'PNEUMONIA')):
        patient_id = extract_patient_ids(filename)
        if patient_id in pneumonia_val_patient_ids:
            pneumonia_val_filenames.append(os.path.join(input_folder, 'PNEUMONIA', filename))
        else:
            pneumonia_train_filenames.append(os.path.join(input_folder, 'PNEUMONIA', filename))

    # Normal (by file, no patient information in file names)
    normal_filenames  = [os.path.join(input_folder, 'NORMAL', fn) for fn in os.listdir(os.path.join(input_folder, 'NORMAL'))]
    normal_val_filenames = random.sample(normal_filenames, int(val_split_perc * len(normal_filenames)))
    normal_train_filenames = list(set(normal_filenames)-set(normal_val_filenames))

    train_filenames = pneumonia_train_filenames + normal_train_filenames
    val_filenames = pneumonia_val_filenames + normal_val_filenames

    return train_filenames, val_filenames


# Define a function for data transformations
def data_transforms(phase):
    # If the phase is TRAIN
    if phase == TRAIN:
        # Compose transformations: Resize, CenterCrop, Convert to Tensor, Normalize
        transform = transforms.Compose([
            transforms.RandomRotation(20),  # Randomly rotate the image within a range of (-20, 20) degrees
            transforms.RandomHorizontalFlip(p=0.5),  # Randomly flip the image horizontally with 50% probability
            transforms.RandomResizedCrop((256,256), scale=(0.8, 1.0)),
            # Randomly crop the image and resize it
            transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.1),
            # Randomly change the brightness, contrast, saturation, and hue
            transforms.RandomApply([transforms.RandomAffine(0, translate=(0.1, 0.1))], p=0.5),
            # Randomly apply affine transformations with translation
            transforms.RandomApply([transforms.RandomPerspective(distortion_scale=0.2)], p=0.5),
            # Randomly apply perspective transformations
            transforms.Resize(size=(256,256)),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])
    # If the phase is VAL
    if phase == VAL:
        # Apply the same transformations as the TRAIN phase
        transform = transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ])

    # If the phase is TEST
    if phase == TEST:
        # Apply the same transformations as the TRAIN phase
        transform = transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ])

    return transform  # Return the composed transformations

def visualize_class_distribution(dataset, dataset_name):
    class_counts = np.zeros(len(dataset.classes))
    for _, y in dataset:
        class_counts[y] += 1

    plt.bar(dataset.classes, class_counts)
    plt.xlabel("Class")
    plt.ylabel("Number of images")
    plt.title(f"Class distribution in the {dataset_name} dataset")
    plt.show()

def calculate_dataset_stats(dataset):
    mean = 0.0
    std = 0.0
    for x, _ in dataset:
        mean += x.mean()
        std += x.std()

    mean /= len(dataset)
    std /= len(dataset)

    return mean.item(), std.item()

def create_weighted_sampler(dataset):
    targets = [label for _, label in dataset]
    class_counts = np.bincount(targets)
    class_weights = 1.0 / class_counts
    weights = [class_weights[label] for label in targets]
    sampler = WeightedRandomSampler(weights, len(weights))
    return sampler

def validation_loss(model, val_loader):
    loss_fn = torch.nn.functional.cross_entropy
    total_loss = 0.0
    model.eval()
    with torch.no_grad():
        for inputs, labels in val_loader:
            inputs = inputs.to(device)  # Move inputs to the same device as the model
            labels = labels.to(device)  # Move labels to the same device as the model
            outputs = model(inputs)
            loss = loss_fn(outputs, labels)
            total_loss += loss.item()
    return total_loss / len(val_loader)


def train_model(model, criterion, optimizer, scheduler, num_epochs):
    best_model_wts = copy.deepcopy(model.state_dict())
    best_acc = 0.0

    train_loss_history = []
    val_loss_history = []

    for epoch in range(num_epochs):
        print("Epoch {}/{}".format(epoch, num_epochs - 1))
        print('-' * 10)

        for phase in [TRAIN, VAL]:
            if phase == TRAIN:
                model.train()  # Set model to training mode
            else:
                model.eval()   # Set model to evaluate mode

            running_loss = 0.0
            running_corrects = 0

            # Iterate over data.
            for inputs, labels in dataloaders[phase]:
                inputs = inputs.to(device)
                labels = labels.to(device)

                optimizer.zero_grad()

                # Forward
                with torch.set_grad_enabled(phase == TRAIN):
                    outputs = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss = criterion(outputs, labels)

                    # Backward + optimize only if in training phase
                    if phase == TRAIN:
                        loss.backward()
                        optimizer.step()

                # Statistics
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)

            epoch_loss = running_loss / dataset_sizes[phase]
            epoch_acc = running_corrects.double() / dataset_sizes[phase]

            print('{} Loss: {:.4f} Acc: {:.4f}'.format(
                phase, epoch_loss, epoch_acc))

            # Store the training and validation loss
            if phase == TRAIN:
                train_loss_history.append(epoch_loss)
                scheduler.step()
            else:
                # Compute the validation loss after the epoch
                epoch_val_loss = validation_loss(model, dataloaders[VAL])
                val_loss_history.append(epoch_val_loss)

            # Deep copy the model
            if phase == VAL and epoch_acc > best_acc:
                best_acc = epoch_acc
                best_model_wts = copy.deepcopy(model.state_dict())

        print()

    print('Best val Acc: {:4f}'.format(best_acc))

    # Load best model weights
    model.load_state_dict(best_model_wts)

    # Plotting the training and validation loss history
    plt.figure(figsize=(10, 6))
    plt.plot(train_loss_history, label='Training Loss')
    plt.plot(val_loss_history, label='Validation Loss')
    plt.title('Training and Validation Loss History')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()

    return model

def test_model():
    # Initialize counters
    running_correct = 0.0
    running_total = 0.0
    true_labels = []
    pred_labels = []
    input_images = []
    correct = 0

    # No need to track gradients for testing
    with torch.no_grad():
        # Iterate over test data
        for data in dataloaders[TEST]:
            inputs, labels = data
            inputs = inputs.to(device)
            labels = labels.to(device)

            # Store true labels
            true_labels.append(labels.item())

            # Store model input images
            input_images.append(inputs)

            # Forward pass
            outputs = model_pre(inputs)
            _, preds = torch.max(outputs.data, 1)

            # Store predicted labels
            pred_labels.append(preds.item())

            correct += (preds == labels).sum().item()

            # Update counters
            running_total += labels.size(0)
            running_correct += (preds == labels).sum().item()

            # Calculate accuracy
            acc = running_correct / running_total

    return true_labels, pred_labels, input_images, running_correct, running_total, acc, correct



if __name__ == '__main__':
    # Initialize the model, data loaders, and other components

    # Check if CUDA is available and set the device accordingly
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(device)  # Print the device being used

    # Define the validation split percentage
    val_split = 0.2
    train_filenames, val_filenames = split_file_names("./data/chest_xray/train/", val_split)

    # Create a dictionary of datasets for each phase (TRAIN, VAL, TEST)
    # For each phase, load the images from the corresponding folder and apply the data transformations
    image_datasets = {
        TRAIN: datasets.ImageFolder("./data/chest_xray/train/", data_transforms(TRAIN),
                                    is_valid_file=lambda x: x in train_filenames),
        VAL: datasets.ImageFolder("./data/chest_xray/train/", data_transforms(VAL),
                                  is_valid_file=lambda x: x in val_filenames),
        TEST: datasets.ImageFolder("./data/chest_xray/test/", data_transforms(TEST))
    }

    # Create a dictionary of dataloaders for each phase
    # For each phase, create a DataLoader that loads the data from the corresponding dataset
    # The batch size and shuffle parameters can be adjusted as needed
    # Replace the train_loader creation with the following code
    if (balance):
        sampler = create_weighted_sampler(image_datasets[TRAIN])
        dataloaders = {
            TRAIN: torch.utils.data.DataLoader(image_datasets[TRAIN], batch_size=4, sampler=sampler, num_workers=4),
            VAL: torch.utils.data.DataLoader(image_datasets[VAL], batch_size=1, shuffle=True),
            TEST: torch.utils.data.DataLoader(image_datasets[TEST], batch_size=1, shuffle=True)
        }

    else:
        dataloaders = {
            TRAIN: torch.utils.data.DataLoader(image_datasets[TRAIN], batch_size=4, shuffle=True, num_workers=4),
            VAL: torch.utils.data.DataLoader(image_datasets[VAL], batch_size=1, shuffle=True),
            TEST: torch.utils.data.DataLoader(image_datasets[TEST], batch_size=1, shuffle=True)
        }

    # Get the sizes of the datasets
    dataset_sizes = {
        x: len(image_datasets[x])
        for x in [TRAIN, VAL]
    }

    # Get the classes from the training dataset
    classes = image_datasets[TRAIN].classes

    # Get the class names from the training dataset
    class_names = image_datasets[TRAIN].classes

    # Visualize class distribution for the TRAIN dataset
    visualize_class_distribution(image_datasets[TRAIN], "Train")

    # Calculate mean and standard deviation for the TRAIN dataset
    mean, std = calculate_dataset_stats(image_datasets[TRAIN])
    print(f"Train dataset mean: {mean:.4f}, standard deviation: {std:.4f}")

    # Visualize class distribution for the TEST dataset
    visualize_class_distribution(image_datasets[TEST], "Test")

    # Calculate mean and standard deviation for the TEST dataset
    mean, std = calculate_dataset_stats(image_datasets[TEST])
    print(f"Test dataset mean: {mean:.4f}, standard deviation: {std:.4f}")

    fig, axes = plt.subplots(6, 6, figsize=(12, 12))
    fig.subplots_adjust(hspace=0.3, wspace=0.3)

    # Function to compute validation loss

    for i in range(6):
        for j in range(6):
            inputs, classes = next(iter(dataloaders[TRAIN]))
            input_img = inputs[0]
            class_label = classes[0]
            inp = input_img.numpy().transpose((1, 2, 0))
            mean = np.array([0.485, 0.456, 0.406])
            std = np.array([0.229, 0.224, 0.225])
            inp = std * inp + mean
            inp = np.clip(inp, 0, 1)
            axes[i, j].imshow(inp)
            axes[i, j].set_title(class_names[class_label.item()])
            axes[i, j].axis('off')

    plt.show()

    inputs, classes = next(iter(dataloaders[TRAIN]))

    # Train the model
    start_time = time.time()

    model_pre = models.vgg16()
    model_pre.load_state_dict(torch.load("./models/vgg16-397923af.pth"))

    # Train the model
    for param in model_pre.features.parameters():
        param.required_grad = False

    num_features = model_pre.classifier[6].in_features
    features = list(model_pre.classifier.children())[:-1]
    features.extend([nn.Linear(num_features, len(class_names))])
    model_pre.classifier = nn.Sequential(*features)
    print(model_pre)

    model_pre = model_pre.to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model_pre.parameters(), lr=0.001, momentum=0.9, weight_decay=0.01)
    # Decay LR by a factor of 0.1 every 10 epochs
    exp_lr_scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)

    model_pre = train_model(model_pre, criterion, optimizer, exp_lr_scheduler, num_epochs=EPOCHS)

    true_labels, pred_labels, input_images, running_correct, running_total, acc, correct = test_model()

    fig, axes = plt.subplots(3, 3, figsize=(7, 7))
    fig.subplots_adjust(hspace=0.7, wspace=0.7)
    x = 0

    for i in range(3):
        for j in range(3):
            # Get the image and labels
            inp = input_images[x].squeeze()

            true_label = true_labels[x]
            pred_label = pred_labels[x]

            # Normalize the image for display
            inp = inp.cpu().numpy().transpose((1, 2, 0))
            mean = np.array([0.485, 0.456, 0.406])
            std = np.array([0.229, 0.224, 0.225])
            inp = std * inp + mean
            inp = np.clip(inp, 0, 1)

            # Display the image
            axes[i, j].imshow(inp)

            # Set the title with the predicted and actual labels
            title = "Predicted: {}\nActual: {}".format(class_names[pred_label], class_names[true_label])
            color = 'green' if pred_label == true_label else 'red'
            axes[i, j].set_title(title, color=color)

            # Hide the axes
            axes[i, j].axis('off')

            # Move to the next image
            x += 1

    plt.show()
    print("Total Correct: {} \nTotal Test Images: {}".format(running_correct, running_total))
    print("Test Accuracy: ", acc)

    print(f"Accuracy on the test set: {correct / len(dataloaders[TEST]):.2%}")

    # Calculate precision, recall, and F1 score using the accumulated true labels and predictions
    precision = precision_score(true_labels, pred_labels)
    recall = recall_score(true_labels, pred_labels)
    f1 = f1_score(true_labels, pred_labels)

    print(f"Precision: {precision:.2f}, Recall: {recall:.2f}, F1 score: {f1:.2f}")

    # Calculate the confusion matrix using the accumulated true labels and predictions
    cm = confusion_matrix(true_labels, pred_labels)

    # Visualize the confusion matrix
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Normal", "Pneumonia"])
    disp.plot()
